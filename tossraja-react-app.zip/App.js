
import React, { useEffect, useState } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyCkOFq2hqB_kRJWePt5OYKdmU3J7TC8NDk",
  authDomain: "tossaraja-2ed24.firebaseapp.com",
  projectId: "tossaraja-2ed24",
  storageBucket: "tossaraja-2ed24.appspot.com",
  messagingSenderId: "769419107605",
  appId: "1:769419107605:web:1c58b1a7779ff787a05d1c"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

function App() {
  const [user, setUser] = useState(null);

  const signIn = () => {
    signInWithPopup(auth, provider)
      .then((result) => {
        setUser(result.user);
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div>
      <h1>Toss Raja – Tez Toss. Double Boss.</h1>
      {user ? (
        <div>
          <p>Welcome, {user.displayName}</p>
          <img src={user.photoURL} alt="User" width={100} />
        </div>
      ) : (
        <button onClick={signIn}>Sign in with Google</button>
      )}
    </div>
  );
}

export default App;
